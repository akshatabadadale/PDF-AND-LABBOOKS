package com.cg.eis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.cg.eis.config.JdbcConfig;
import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class DaoJdbcClass implements DaoInterface {

	Connection connection = null;
	PreparedStatement statement = null;

	public DaoJdbcClass() {
		try {
			this.connection = JdbcConfig.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Employee storeEmployee(Employee employee) {

		return null;
	}

	@Override
	public Map<Integer, Employee> displayEmployees() {

		try {

			Map<Integer, Employee> map = new HashMap<Integer, Employee>();
			statement = connection.prepareStatement(getAllEmployee);

			ResultSet set = statement.executeQuery();

			while (set.next()) {
				Employee e = new Employee();
				e.setName(set.getString(2));
				e.setDesignation(set.getString(3));
				e.setSalary(set.getDouble(4));
				map.put(set.getInt(1), e);
			}

			return map;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Employee displayEmployeeById(int id) throws EmployeeException {
		try {
			statement = connection.prepareStatement(getEmployee);
			statement.setInt(1, id);

			ResultSet set = statement.executeQuery();
			Employee e = new Employee();
			if (set.next()) {
				e.setName(set.getString(2));
				e.setDesignation(set.getString(3));
				e.setSalary(set.getDouble(4));
				return e;
			}
			else
			{
				throw new EmployeeException("No Employee Found");
			}

		} 
		catch (SQLException e) {
			throw new EmployeeException("No Employee Found");
		}

	}

	@Override
	public String getInsuranceScheme(int id) throws EmployeeException {

		try {
			statement = connection.prepareStatement(getEmployee);
			statement.setInt(1, id);

			ResultSet set = statement.executeQuery();
			Employee employee = new Employee();
			if (set.next()) {
				employee.setName(set.getString(2));
				employee.setDesignation(set.getString(3));
				employee.setSalary(set.getDouble(4));
			}
			if (employee.getSalary() < 5000
					&& employee.getDesignation().equalsIgnoreCase("clerk")) {
				return "No insurance scheme for clerk";
			} else if (employee.getSalary() >= 40000
					&& employee.getDesignation().equalsIgnoreCase("manager")) {
				return "You are eligible for insurance scheme A";
			} else if (employee.getSalary() >= 20000
					&& employee.getSalary() < 40000
					&& employee.getDesignation().equalsIgnoreCase("Programmer")) {
				return "You are eligible for insurance scheme B";
			} else {
				return "You are eligible for insurance scheme C";
			}
		} catch (SQLException e) {
			return null;
		}
	}

}
