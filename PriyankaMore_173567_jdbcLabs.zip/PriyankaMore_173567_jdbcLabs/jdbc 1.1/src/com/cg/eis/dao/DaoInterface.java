package com.cg.eis.dao;

import java.util.Map;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface DaoInterface {
	Employee storeEmployee(Employee employee);
	
	Map<Integer,Employee> displayEmployees();
	
	Employee displayEmployeeById(int id) throws EmployeeException;
	
	String getInsuranceScheme(int id) throws EmployeeException;
	
	String getEmployee = "Select * from employee where eid = ?";
	
	String getAllEmployee = "Select * from employee";
}
