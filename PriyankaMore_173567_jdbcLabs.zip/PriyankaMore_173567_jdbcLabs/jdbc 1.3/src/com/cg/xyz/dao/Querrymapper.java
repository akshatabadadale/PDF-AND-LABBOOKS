package com.cg.xyz.dao;

public interface Querrymapper {
	String insertAuthor ="insert into author values(seq_author.nextval,?,?,?,?)";
	String insertBook = "insert into book values(seq_isbn.nextval,?,?)";
	String insertRef = "insert into bookauthorref values(seq_refid.nextval,?,?)";
	String update = "update book set price=? where isbn=?";
	String delete = " delete from author where AUTHORID=?";
	String getAuthor = "select * from author";
	String getBook = "select b.* from book b ,bookauthorref br where br.authorid=? and  b.isbn=br.bookid";
	String authid = "select max(authorid) from author";
	String bookid = "select max(isbn) from book";
}
