package com.cg.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.xyz.bean.Author;
import com.cg.xyz.config.JdbcConfig;

public class DatabaseDao implements IDatabaseDao {
	PreparedStatement statement = null;
	Connection connection;
	ResultSet rs = null;

	public DatabaseDao() {
		try {
			connection = JdbcConfig.getConnection();
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}

	public void insertIntodatabase(Author auth) throws SQLException {
		statement = connection.prepareStatement(Querrymapper.insertAuthor);
		statement.setString(1, auth.getFirstname());
		statement.setString(2, auth.getMiddleName());
		statement.setString(3, auth.getLastName());
		statement.setLong(4, auth.getMobile());
		statement.executeUpdate();
		System.out.println("Author Added");
	}


	@Override
	public void update(long mob,int id) throws SQLException {
		statement = connection.prepareStatement(Querrymapper.update);
		statement.setLong(1, mob);
		statement.setInt(2, id);
		statement.executeUpdate();
		System.out.println("Author Updated");
	}

	@Override
	public void delete(int id) throws SQLException {
		statement = connection.prepareStatement(Querrymapper.delete);
		statement.setInt(1, id);	
		statement.executeQuery();
		System.out.println("Author Deleted");
	}

}