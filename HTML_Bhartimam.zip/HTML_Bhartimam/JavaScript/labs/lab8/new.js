function getCategory(){
 
            var list1 = document.getElementById('FirstList');
            var list2 = document.getElementById("secondList");
            var list1SelectedValue = list1.options[list1.selectedIndex].value;
             
            if (list1SelectedValue=='Electronics')
            {
                 
                list2.options.length=0;
                list2.options[0] = new Option('--Select--', '');
                list2.options[1] = new Option('Television', 'Television');
                list2.options[2] = new Option('Laptop', 'Laptop');
                list2.options[3] = new Option('Phone', 'Phone');
                
            }
            else if (list1SelectedValue=='Groceries')
            {
                 
                list2.options.length=0;
                list2.options[0] = new Option('--Select--', '');
                list2.options[1] = new Option('Soap', 'Soap');
                list2.options[2] = new Option('Powder', 'Powder');
                
                 
            }
}